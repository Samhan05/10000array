
package random.arrays;
//Java's Random class to generate random integers(java.util.Random;)
import java.util.Random;
public class assigment {
    public static void main(String[] args) {
     int[] array = new int[10000];   
     Random rand = new Random();
//max, min, and sum
     int max = Integer.MIN_VALUE;
     int min = Integer.MAX_VALUE;
     double sum = 0;
// Fill array with random numbers and calculate max, min, and sum
    for(int i=0; i < array.length; i++) {
    array[i]= rand.nextInt(10000);
    sum += array[i];
      
       if (array[i]>max){
           max = array[i];}
       if (array[i]<min){
           min = array[i];}
     
    }
  double avg = sum / array.length;
  
  //now we print the results
        System.out.println("max value:" + max);
        System.out.println("Min value:" + min);
        System.out.println("Avarage value:" + avg);
  //finally we print the array
System.out.println("array aontents:");       
for (int i = 0; i< array.length; i++){
       System.out.print(array[i] + " ");
        if((i + 1)% 20==0)System.out.println();}
        
        
        
        
        
    }
    
}
